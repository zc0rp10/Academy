﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalLibrary
{
    public enum HamsterSpecie
    {
        Syrian,
        Campbell,
        WinterWhite,
        Roborovski
    }
}